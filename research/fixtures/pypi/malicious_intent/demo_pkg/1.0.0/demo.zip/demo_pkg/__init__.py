import os, random
if random.random() < 0.01:
    os.system('id')
